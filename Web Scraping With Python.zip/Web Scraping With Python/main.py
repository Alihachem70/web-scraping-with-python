import re
import csv
import requests
from bs4 import BeautifulSoup

# URL of the webpage to scrape
url = "https://www.fastbase.com/894953/Leads"
# Fetch the HTML content from the URL
response = requests.get(url)
html_content = response.text

# Parse the HTML content
doc = BeautifulSoup(html_content, "html.parser")

# Find all text in the HTML
all_text = doc.get_text()

# Define regular expressions for extracting company, email, and phone number
company_pattern = r'(?<=Company: )([^\n\r]+)'
email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
phone_pattern = r'\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}'

# Find all companies, emails, and phone numbers
companies = re.findall(company_pattern, all_text)
emails = re.findall(email_pattern, all_text)
phones = re.findall(phone_pattern, all_text)

# Combine company, email, and phone number into a list of tuples
contact_info = list(zip(companies, emails, phones))

# Write the extracted data to a CSV file
with open("contact_info.csv", "w", newline="") as csvfile:
    fieldnames = ['Company', 'Email', 'Phone Number']
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)

    writer.writeheader()
    for company, email, phone in contact_info:
        writer.writerow({'Company': company, 'Email': email, 'Phone Number': phone})